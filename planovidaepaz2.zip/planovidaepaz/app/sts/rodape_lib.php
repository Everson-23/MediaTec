<!-- Core JavaScript Files-->
<script src="<?php echo pg; ?>/assets/js/jquery.min.js"></script>
<script src="<?php echo pg; ?>/assets/js/bootstrap.min.js"></script>
<script src="<?php echo pg; ?>/assets/js/jquery.easing.min.js"></script>
<script src="<?php echo pg; ?>/assets/js/wow.min.js"></script>
<script src="<?php echo pg; ?>/assets/js/jquery.scrollTo.js"></script>
<script src="<?php echo pg; ?>/assets/js/jquery.appear.js"></script>
<script src="<?php echo pg; ?>/assets/js/stellar.js"></script>
<script src="<?php echo pg; ?>/assets/plugins/cubeportfolio/js/jquery.cubeportfolio.min.js"></script>
<script src="<?php echo pg; ?>/assets/js/custom.js"></script>
<script src="<?php echo pg; ?>/assets/js/nivo-lightbox.min.js"></script>

<script src="<?php echo pg; ?>/assets/js/owl.carousel.js"></script>
<script src="<?php echo pg; ?>/assets/js/owl.carousel.min.js"></script>
<!-- Control de Responsive Design !-->
<script>
$(document).ready(function() {
$("#owl-demo").owlCarousel({
autoPlay: 7000,
items : 2,
itemsDesktop : [1199,1],
itemsDesktopSmall : [979,1],
itemsTablet: [768,1],
itemsTabletSmall: [568,1],
itemsMobile: [0,1],
});
});
</script>

<!--Start of Tawk.to Script-->
<script type="text/javascript">
    var Tawk_API = Tawk_API || {},
            Tawk_LoadStart = new Date();
    (function () {
        var s1 = document.createElement("script"),
                s0 = document.getElementsByTagName("script")[0];
        s1.async = true;
        s1.src = 'https://embed.tawk.to/5b5b6116df040c3e9e0c08b2/default';
        s1.charset = 'UTF-8';
        s1.setAttribute('crossorigin', '*');
        s0.parentNode.insertBefore(s1, s0);
    })();
</script>
<!--End of Tawk.to Script-->
