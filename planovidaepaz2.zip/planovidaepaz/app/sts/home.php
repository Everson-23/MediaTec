<?php
if (!isset($seguranca)) {
    exit;
}
include_once 'app/sts/header.php';
?>
<link href="../../assets/css/style.css" rel="stylesheet" type="text/css">
<body id="page-top" data-spy="scroll" data-target=".navbar-custom">
<?php
include_once 'app/sts/menu.php';
?>
<section id="intro" class="intro">
    <div class="intro-content">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="wow fadeInDown" data-wow-offset="0" data-wow-delay="0.1s">
                        <h2 class="h-ultra" style="color:#1b56b5;">Plano Vida & Paz</h2>
                    </div>
                    <div class="wow fadeInUp" data-wow-offset="0" data-wow-delay="0.1s">
                        <h4 class="h-light" style="color:#1b56b5;">Contribuir em serviços póstumos, tendo como primordial o respeito.</h4>
                    </div>
                    <!--<div class="well well-trans">
                        <div class="wow fadeInRight" data-wow-delay="0.1s">
                            <ul class="lead-list">
                                <li><span class="fa fa-check fa-2x" style="color:#1b56b5;"></span><span class="list"><strong style="color:#fff;">Amplos salões velatórios.</strong><br/></span>
                                </li>
                                <li><span class="fa fa-check fa-2x" style="color:#1b56b5;"></span> <span class="list"><strong style="color:#fff;">Velório Virtual.</strong><br/></span>
                                </li>
                                <li><span class="fa fa-check fa-2x" style="color:#1b56b5;"></span> <span class="list"><strong style="color:#fff;">Suíte reservada ao descanso á família.</strong><br/></span>
                                </li>
                                <li><span class="fa fa-check fa-2x" style="color:#1b56b5;"></span> <span class="list"><strong style="color:#fff;">Assitência funerária com plantão 24 horas.</strong><br/></span>
                                </li>
                                <li><span class="fa fa-check fa-2x" style="color:#1b56b5;"></span> <span class="list"><strong style="color:#fff;">Remoção, cortejo fúnebre e transporte de familiares.</strong><br/></span>
                                </li>
                            </ul>
                        </div> -->
                    </div> 
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /Section: intro -->
<!-- Section: boxes -->
<?php

$result_valores = "SELECT * FROM sts_volores_empresa LIMIT 1";
$resultado_valores = mysqli_query($conn, $result_valores);
$row_valores = mysqli_fetch_assoc($resultado_valores);
?>
<section id="boxes" class="home-section paddingtop-80">
    <div class="container" style="position: relative;">
        <div class="row">
            <div class="col-sm-4 col-md-4">
                <div class="wow fadeInUp" data-wow-delay="0.2s">
                    <div class="box text-center">
                        <i class="fa fa-5x circled bg-skin">
                            <div <?php echo $row_valores['icone_um']; ?>></div>
                        </i>
                        <h4 class="h-bold"><?php echo $row_valores['nome_um']; ?></h4>
                        <p>
                            <?php echo $row_valores['descricao_um']; ?>
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-sm-4 col-md-4">
                <div class="wow fadeInUp" data-wow-delay="0.2s">
                    <div class="box text-center">
                        <i class="fa fa-5x circled bg-skin">
                            <div <?php echo $row_valores['icone_dois']; ?>></div>
                        </i>
                        <h4 class="h-bold"><?php echo $row_valores['nome_dois']; ?></h4>
                        <p>
                            <?php echo $row_valores['descricao_dois']; ?>
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-sm-4 col-md-4">
                <div class="wow fadeInUp" data-wow-delay="0.2s">
                    <div class="box text-center">
                        <i class="fa fa-5x circled bg-skin">
                            <div <?php echo $row_valores['icone_tres']; ?>></div>
                        </i>
                        <h4 class="h-bold"><?php echo $row_valores['nome_tres']; ?></h4>
                        <p>
                            <?php echo $row_valores['descricao_tres']; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /Section: boxes -->
<?php
include_once 'app/sts/instalacao.php';
?>
<!-- Section: pricing -->
<section id="pricing" class="home-section bg-gray paddingbot-20 testimonial-top">
    <div class="container marginbot-50">
        <div class="row">
            <div class="col-lg-8 col-lg-offset-2" style ="position:relative;">
                <div class="wow lightSpeedIn" data-wow-delay="0.1s">
                    <div class="section-heading text-center">
                        <h2 id="planos" class="h-bold" style="padding-top: 80px;">Planos</h2>
                       
                    </div>
                </div>
                <div class="divider-short"></div>
            </div>
        </div>
    </div>
   <div class="container">
        <div class="row" style="position:relative;">
            <div class="col-sm-3 pricing-box">
                <div class="wow bounceInUp" data-wow-delay="0.1s">
                    <div class="pricing-content general color-hover">
                        <h2>Plano Econômico - 1 Titular<br/> + 4 Dependentes</h2>
                        <ul>
                            <li>Urna mortuária c/visor</li>
                            <li>Ornamentação floral</li>
                            <li>Transporte fúnebre (até 200 km rodados)</li>
                            <li>Lembrança 7º dia (40 Unid.)</li>
                        </ul>
                        <div class="price-bottom">
                            <a href="#contact-us" class="btn btn-skin btn-lg">Eu quero</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-3 pricing-box">
                <div class="wow bounceInUp" data-wow-delay="0.1s">
                    <div class="pricing-content general color-hover">
                        <h2>Plano Básico - 1 Titular<br/> + 9 Dependentes</h2>
                        <ul>
                            <li>Urna mortuária c/visor</li>
                            <li>Ornamentação floral</li>
                            <li>Transporte fúnebre (até 200 km rodados)</li>
                            <li>Lembrança 7º dia (60 Unid.)</li>
                        </ul>
                        <div class="price-bottom">
                            <a href="#contact-us" class="btn btn-skin btn-lg">Eu quero</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-3 pricing-box">
                <div class="wow bounceInUp" data-wow-delay="0.1s">
                    <div class="pricing-content general color-hover">
                        <h2>Plano Especial - 1 Titular<br/> + 9 Dependentes</h2>
                        <ul>
                            <li>Urna mortuária c/visor</li>
                            <li>Ornamentação floral</li>
                            <li>Transporte fúnebre (até 200 km rodados)</li>
                            <li>Lembrança 7º dia (80 Unid.)</li>
                        </ul>
                        <div class="price-bottom">
                            <a href="#contact-us" class="btn btn-skin btn-lg">Eu quero</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-3 pricing-box ">
                <div class="wow bounceInUp" data-wow-delay="0.3s">
                    <div class="pricing-content general color-hover">
                        <h2>Plano Luxo - 1 Titular<br/> + 9 Dependentes</h2>
                        <ul>
                            <li>Urna mortuária c/visor</li>
                            <li>Ornamentação floral</li>
                            <li>Transporte fúnebre (até 200 km rodados)</li>
                            <li>Lembrança 7º dia (100 Unid.)</li>
                        </ul>
                        <div class="price-bottom">
                            <a href="#contact-us" class="btn btn-skin btn-lg">Eu quero</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
include_once 'app/sts/depoimento.php';
?>
<?php
include_once 'app/sts/evento.php';
?>
<section id="contact-s" id="contact home-section paddingbot-60 parallax testimonial-top">
    <div id="contact-us" class="parallax">  
        <div class="container">
            <div class="row">
                <div class="heading text-center col-sm-8 col-sm-offset-2 wow fadeInUp" data-wow-duration="1000ms"
                     data-wow-delay="300ms">
                    <h2 style="color:#fff;">Contato</h2>
                </div>
            </div>
            <div class="contact-form wow fadeIn" data-wow-duration="1000ms" data-wow-delay="600ms">
                <div class="row">
                    <div class="col-sm-6">
                        <form id="main-contact-form" method="post">
                            <div class="row  wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="300ms">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <font color="white">Nome:</font>
                                        <input class="form-control" id="id_nome" name="nome" placeholder="Nome"
                                               required="required" type="text"/>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                <font color="white">Telefone:</font>
                                    <div class="form-group">
                                        <input class="form-control" id="id_telefone" name="telefone"
                                               placeholder="Telefone" required="required" type="tel"/>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="form-group">
                                    <font color="white">E-mail:</font>
                                        <input class="form-control" id="id_e_mail" name="e_mail" placeholder="Email"
                                               required="required" type="e-mail"/>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                            <font color="white">Escolha uma opção:</font>
                                <select class="form-control" id="id_assunto" name="assunto">
                                    <option value="" selected style="color:white;">Escolha uma opção</option>
                                    <option value="Duvidas com o plano" >Dúvidas com o plano</option>
                                   <option value="Adquirir um plano" >Adquirir o seu Plano</option>
                                    <option value="Reportar um Erro" >Reportar um erro</option>
                                </select>
                            </div>
                            <div class="form-group">
                            <font color="white">Digite sua mensagem:</font>
                                    <textarea class="form-control" cols="40" id="id_mensagem" name="mensagem" placeholder="Digite sua mensagem" required="required" rows="10" style="color:black;"></textarea>
                            </div>
                            <div class="form-group">
                                <button type="submit" id="sendmail" value="sendmail" name="sendmail"
                                        class="btn btn-lg btn-block bg-skin">Enviar Agora
                                </button>
                            </div>
                        </form>
                        <!-- Resultado se foi enviado o email-->
                        <div id="resultado"></div>
                    </div>
                    <div class="col-sm-6">
                        <div class="contact-info wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="300ms">
                            <ul class="address" style="color: rgba(255,255,255,0.81)">
                                <li><i class="fa fa-map-marker"></i> <span> Endereço:<br /></span>
                                    <strong>Matriz:</strong> Av. Osório de Paiva, 5550 - Siqueira - Fortaleza-CE<br />
                                    <strong>Filial:</strong> Av. IX, 693 - Jereissati II - Maracanaú-CE
                                </li>
                                <li><i class="fa fa-phone"></i> <span> Telefone:</span> (85) 4141-4177 - 3498-3162</li>
                                <li><i class="fa fa-whatsapp"></i> <span> Whatsapp:</span> (85) 98922-5949</li>
                                <li><i class="fa fa-envelope"></i> <span> Email:</span><a href="#"> vidaepaz2009@hotmail.com</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--/#contact-->
<?php
include_once 'app/sts/rodape.php';
include_once 'app/sts/rodape_lib.php';
?>
</body>
