<div id="wrapper">
    <nav class="navbar navbar-custom " role="navigation">
        <div class="top-area" id="home"></div>
        <div class="container-fluid logo-center"  >
          <br>
          <br>
          <div>
            <img class="img-logo img-fluid" alt="Responsive image" src="<?php echo pg;?>/assets/img/logo/logo.png" width="20%" height="12%">
            <img class="img-logo-otc img-fluid" alt="Responsive image" src="<?php echo pg;?>/assets/img/logo/logo1.jpeg" width="30%" height="30%">
            <div class="ligue-agora">

            </div>
          </div>

        </div>
        <div class="container navigation">
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-center navbar-main-collapse"  style="position:fixed; background-color:#ffffff; top:0px; width:100%; z-index:5;left:0px;">
                <ul class="nav navbar-nav" style="text-align:center;">
                    <li class="active"><a href="#home">Home</a></li>
                    <li><a href="#installation">Instalações</a></li>
                    <li><a href="#planos">Planos</a></li>
                    <li><a href="#testimonial">Depoimentos</a></li>
                    <li><a href="#evento">Eventos</a></li>
                    <li><a href="obituario.php">Obituário online</a></li>
                  <li><a href="#contact-us">Contato</a></li>
                  <li><a style="color: #4169E1; font-size: 16px;">Ligue agora:&nbsp;&nbsp;(85) 3498 3162 &nbsp;&nbsp; (85) 4141 4177</a></li>
                    </div>
                    </li>


                </ul>
                            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
    <!-- Section: intro -->
