 <!-- Section: testimonial -->
    <section id="testimonial" class="home-section paddingbot-60 parallax testimonial-top" data-stellar-background-ratio="0.5">
        <div class="container marginbot-50">
            <div class="row">
                <div class="col-lg-12 col-lg-offset-">
                    <div class="wow fadeInDown" data-wow-delay="0.1s">
                        <div class="section-heading text-center" >
                            <h2 class="h-bold" style="color:#fff;">Depoimentos</h2>
                        </div>
                    </div>
                    <div class="divider-short"></div>
                </div>
            </div>
        </div>
        <div class="carousel-reviews broun-block">
            <div class="container">
                <div class="row">
                    <div id="carousel-reviews" class="carousel slide" data-ride="carousel" style="position:none; ">
                        <div class="carousel-inner">
                          <div class="item active">
                            <div class="col-md-4 col-sm-6">
                              <div class="block-text rel zmin">
                                <a>Joana</a>
                                <div class="mark">Minha Classificação:
                                   <span class="rating-input">
                                     <span data-value="0" class="glyphicon glyphicon-star"></span>
                                     <span data-value="1" class="glyphicon glyphicon-star"></span>
                                     <span data-value="2" class="glyphicon glyphicon-star"></span>
                                     <span data-value="3" class="glyphicon glyphicon-star"></span>
                                     <span data-value="4" class="glyphicon glyphicon-star"></span>
                                   </span>
                                </div>
                                <p>Já tenho esse plano à quase 12 anos, antes dele eu tinha o plano SBC, mas me deixou muito a desejar, inclusive no valor do plano que era abusivo, então conheci o plano vida e paz, onde tem os mesmos direitos, mas com um valor menor e mais acessivo.</p>
                              </div>
                            </div>
                            <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
                              <div class="block-text rel zmin">
                                <a>Caroline</a>
                                <div class="mark">Minha Classificação:
                                   <span class="rating-input">
                                     <span data-value="0" class="glyphicon glyphicon-star"></span>
                                     <span data-value="1" class="glyphicon glyphicon-star"></span>
                                     <span data-value="2" class="glyphicon glyphicon-star"></span>
                                     <span data-value="3" class="glyphicon glyphicon-star"></span>
                                     <span data-value="4" class="glyphicon glyphicon-star"></span>
                                   </span>
                                </div>
                                <p>Muito bom... Super indico, atendimento maravilhoso, pessoas prontas para lhe atender.</p>
                              </div>
                            </div>
                            <div class="col-md-4 col-sm-6 hidden-xs">
                              <div class="block-text rel zmin">
                                <a>Isabele</a>
                                <div class="mark">Minha Classificação:
                                   <span class="rating-input">
                                     <span data-value="0" class="glyphicon glyphicon-star"></span>
                                     <span data-value="1" class="glyphicon glyphicon-star"></span>
                                     <span data-value="2" class="glyphicon glyphicon-star"></span>
                                     <span data-value="3" class="glyphicon glyphicon-star"></span>
                                     <span data-value="4" class="glyphicon glyphicon-star"></span>
                                   </span>
                                </div>
                                <p>Só tenho a agradecer o serviço prestado pelo Plano vida e paz. No momento mais difícil que é a perca de um ente querido, quando precisamos de força para superar a tristeza e resolver várias questões burocráticas, a família teve toda a assistência e estrutura necessária.</p>
                              </div>
                            </div>
                          </div>
                          <div class="item">
                            <div class="col-md-4 col-sm-6">
                              <div class="block-text rel zmin">
                                <a>Roberto</a>
                                <div class="mark">Minha Classificação:
                                   <span class="rating-input">
                                     <span data-value="0" class="glyphicon glyphicon-star"></span>
                                     <span data-value="1" class="glyphicon glyphicon-star"></span>
                                     <span data-value="2" class="glyphicon glyphicon-star"></span>
                                     <span data-value="3" class="glyphicon glyphicon-star"></span>
                                     <span data-value="4" class="glyphicon glyphicon-star"></span>
                                   </span>
                                </div>
                                <p>Agradeço à toda equipe pelo lindo velório que fizeram para o meu pai e nos acolheram com muito carinho.</p>
                              </div>
                            </div>
                            <div class="col-md-4 col-sm-6 hidden-xs">
                              <div class="block-text rel zmin">
                                <a>Fernanda</a>
                                <div class="mark">Minha Classificação:
                                   <span class="rating-input">
                                     <span data-value="0" class="glyphicon glyphicon-star"></span>
                                     <span data-value="1" class="glyphicon glyphicon-star"></span>
                                     <span data-value="2" class="glyphicon glyphicon-star"></span>
                                     <span data-value="3" class="glyphicon glyphicon-star"></span>
                                     <span data-value="4" class="glyphicon glyphicon-star"></span>
                                   </span>
                                </div>
                                <p>No momento mais difícil que é a perca de um ente querido, quando precisamos de força para superar a tristeza e resolver várias questões burocráticas, a família teve toda a assistência e estrutura necessária.</p>
                              </div>
                            </div>
                            <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
                              <div class="block-text rel zmin">
                                <a >Fatima</a>
                                <div class="mark">Minha Classificação:
                                   <span class="rating-input">
                                     <span data-value="0" class="glyphicon glyphicon-star"></span>
                                     <span data-value="1" class="glyphicon glyphicon-star"></span>
                                     <span data-value="2" class="glyphicon glyphicon-star"></span>
                                     <span data-value="3" class="glyphicon glyphicon-star"></span>
                                     <span data-value="4" class="glyphicon glyphicon-star"></span>
                                   </span>
                                </div>
                                <p>Obrigada por tudo! Sem a ajuda de vocês seria muito difícil pra nós darmos conta de tudo sozinho.</p>
                              </div>
                            </div>
                          </div>

                          <!--
                              <?php
                              $cont_slide = 0;
                              $result_depoimentos = "SELECT * FROM sts_depoimentos WHERE sts_situacoe_id=1";
                              $resultado_depoimentos = mysqli_query($conn, $result_depoimentos);

                              if (($resultado_depoimentos) AND ( $resultado_depoimentos->num_rows != 0)) {?>
                                  <?php
                                    $resultado_depoimentos = mysqli_query($conn, $result_depoimentos);
                                    while ($row_slide = mysqli_fetch_assoc($resultado_depoimentos)) { ?>
                                    <div class="item <?php if($cont_slide == 0){echo'active';}?>">
                                      <div class="col-md-4 col-sm-6">
                                          <div class="block-text rel zmin">
                                              <a><?php echo $row_slide['nome_cliente']; ?></a>
                                              <div class="mark">My rating:
                                              <span class="rating-input">
                                                <span data-value="0" class="glyphicon glyphicon-star"></span>
                                                <span data-value="1" class="glyphicon glyphicon-star"></span>
                                                <span data-value="2" class="glyphicon glyphicon-star"></span>
                                                <span data-value="3" class="glyphicon glyphicon-star"></span>
                                                <span data-value="4" class="glyphicon glyphicon-star-empty"></span>
                                              </span>
                                              </div>
                                              <p>
                                                Ne eam errem semper. Laudem detracto phaedrum cu vim, pri cu errem fierent fabellas. Quis magna in ius, pro vidit nonumy te, nostrud ...</p>
                                              <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                                          </div>
                                      </div>
                                      <div class="col-md-4 col-sm-6 hidden-xs">
                                          <div class="block-text rel zmin">
                                            <a><?php echo $row_slide['nome_cliente']; ?></a>
                                              <div class="mark">My rating:
                                                <span class="rating-input">
                                                  <span data-value="0" class="glyphicon glyphicon-star"></span>
                                                  <span data-value="1" class="glyphicon glyphicon-star"></span>
                                                  <span data-value="2" class="glyphicon glyphicon-star-empty"></span>
                                                  <span data-value="3" class="glyphicon glyphicon-star-empty"></span>
                                                  <span data-value="4" class="glyphicon glyphicon-star-empty"></span>
                                                </span>
                                              </div>
                                              <p>Ne eam errem semper. Laudem detracto phaedrum cu vim, pri cu errem fierent fabellas. Quis magna in ius, pro vidit nonumy te, nostrud ...</p>
                                              <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                                          </div>
                                      </div>
                                      <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
                                          <div class="block-text rel zmin">
                                              <a><?php echo $row_slide['nome_cliente']; ?></a>
                                              <div class="mark">My rating:
                                                <span class="rating-input">
                                                  <span data-value="0" class="glyphicon glyphicon-star"></span>
                                                  <span data-value="1" class="glyphicon glyphicon-star"></span>
                                                  <span data-value="2" class="glyphicon glyphicon-star"></span>
                                                  <span data-value="3" class="glyphicon glyphicon-star"></span>
                                                  <span data-value="4" class="glyphicon glyphicon-star"></span>
                                                </span>
                                              </div>
                                              <p>Ne eam errem semper. Laudem detracto phaedrum cu vim, pri cu errem fierent fabellas. Quis magna in ius, pro vidit nonumy te, nostrud ...</p>
                                              <ins class="ab zmin sprite sprite-i-triangle block"></ins>
                                          </div>
                                      </div>
                                  </div>
                                  <?php
                                  $cont_slide++;
                                  }
                                  ?>
                              <?php
                                }
                              ?>
                            -->
                        </div>
                    </div>
                    <a class="left carousel-control" href="#carousel-reviews" role="button" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left"></span>
                    </a>
                    <a class="right carousel-control" href="#carousel-reviews" role="button" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right"></span>
                    </a>
                </div>
            </div>
        </div>
    </section>
    <!-- /Section: testimonial -->
