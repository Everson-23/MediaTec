<?php
	$noticia = "SELECT * FROM sts_eventos ORDER BY id DESC";

	$noticias=mysqli_query($conn,$noticia);

	function recortar_texto($texto, $limite=100){
    $texto = trim($texto);
    $texto = strip_tags($texto);
    $tamano = strlen($texto);
    $resultado = '';
    if($tamano <= $limite){
        return $texto;
    }else{
        $texto = substr($texto, 0, $limite);
        $palabras = explode(' ', $texto);
        $resultado = implode(' ', $palabras);
        $resultado .= '...';
    }
    return $resultado;
	}
?>

<section id="evento" class="home-section paddingbot-60 slider testimonial-top">
    <div class="noticias">
        <div class="container evento" style="height:800px;">
					<div class="container marginbot-50">
							<div class="row">
									<div class="col-lg-8 col-lg-offset-2">
											<div class="wow fadeInDown" data-wow-delay="0.1s">
													<div class="section-heading text-center">
															<h2 class="h-bold">Eventos</h2>
															<p></p>
													</div>
											</div>
											<div class="divider-short"></div>
									</div>
							</div>
					</div>
            <div class="grid_12">
                <div id="owl-demo" class="owl-carousel-evento">
                <?php
                while ($not=$noticias->fetch_assoc()) {  $cadena= $not['conteudo']; $titulo= $not['nome'];?>
                    <div class="item">
                        <div class="img_noticias" style="background-image:url(<?php echo pg; ?>/assets/img/noticias/<?php echo $not['img'];?>);">
                        </div>
                        <div class="text_noticias">
                        	<!-- Secciones de Carousel !-->
                            <div class="span"><?php echo $not['data'];?></div>
                            <h3><?php echo recortar_texto($titulo, 54);?></h3>
                            <p><?php echo recortar_texto($cadena, 150);?></p>
                            <a  class="fancybox" href="#inline<?php echo $not['id'];?>" >Ver mais >></a>
                            <!-- LigthBox De Noticias !-->
                            <div id="inline<?php echo $not['id'];?>" style="width:500px;display: none;">
                            <h3 style="margin-bottom:2px;"><?php echo $not['nome'];?></h3>
                            <div class="span"><?php echo $not['data'];?></div><br>
                            <img src="<?php echo pg; ?>/assets/img/noticias/<?php echo $not['img'];?>" style="width:100%; margin-bottom:10px;">
                            <?php echo $not['conteudo'];?>
                        </div>
                    </div>
                    </div>
                <?php } ?>

                </div>
            </div>
        </div>
    </div>
</section>
