<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo $row_pagina['nome_pagina']; ?></title>
    <meta name="robots" content="<?php echo $row_pagina['robots']; ?>">
    <meta name="keywords" content="<?php echo $row_pagina['keywords']; ?>">
    <meta name="description" content="<?php echo $row_pagina['description']; ?>">
    <meta name="author" content="<?php echo $row_pagina['author']; ?>">

    <!-- css -->
    <link href="<?php echo pg; ?>/assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?php echo pg; ?>/assets/css/animate.css" rel="stylesheet" />
    <link href="<?php echo pg; ?>/assets/font-awesome/css/font-awesome.min.css" rel="stylesheet"  />
    <link href="<?php echo pg; ?>/assets/plugins/cubeportfolio/css/cubeportfolio.min.css" rel="stylesheet" />

    <link href="<?php echo pg; ?>/assets/css/nivo-lightbox.css" rel="stylesheet" />
    <link href="<?php echo pg; ?>/assets/css/nivo-lightbox-theme/default/default.css" rel="stylesheet" type="text/css" />

    <link href="<?php echo pg; ?>/assets/font/fonts.css" rel="stylesheet" media="screen">
    <link href="<?php echo pg; ?>/assets/css/style.css" rel="stylesheet" />
    <link href="<?php echo pg; ?>/assets/css/style_evento.css" rel="stylesheet" />

    <!-- Owl Carousel Assets -->
    <link href="<?php echo pg; ?>/assets/css/owl.carousel1.css" rel="stylesheet">
    <link href="<?php echo pg; ?>/assets/css/owl.theme1.css" rel="stylesheet">

    <link href="<?php echo pg; ?>/assets/css/owl.carousel.css" rel="stylesheet">
    <link href="<?php echo pg; ?>/assets/css/owl.theme.css" rel="stylesheet">



    <script src="<?php echo pg; ?>/assets/js/jquery-1.7.1.min.js"></script>


    <!-- boxed bg -->
    <link id="bodybg" href="<?php echo pg; ?>/assets/css/bodybg/bg1.css" rel="stylesheet" type="text/css" />
    <!-- template skin -->
    <link id="t-colors" href="<?php echo pg; ?>/assets/css/thema/default.css" rel="stylesheet">

    <!-- css externo -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

    <!-- Add JS -->
    <script src="<?php echo pg; ?>/assets/js/jquery-3.1.1.min.js" type="text/javascript"></script>
    <script src="<?php echo pg; ?>/assets/js/index.js" type="text/javascript"></script>

    <script type="text/javascript" src="<?php echo pg; ?>/assets/source/jquery.fancybox.js?v=2.1.5"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo pg; ?>/assets/source/jquery.fancybox.css?v=2.1.5" media="screen" />
    <script type="text/javascript">
    	$(document).ready(function() {
    		$('.fancybox').fancybox();
    	});
    </script>

</head>
