<!-- Section: works -->
<section id="installation" class="home-section paddingbot-60 testimonial-top">
    <div class="container marginbot-50">
        <div class="row">
            <div class="col-lg-8 col-lg-offset-2">
                <div class="wow fadeInDown" data-wow-delay="0.1s">
                    <div class="section-heading text-center">
                        <h2 class="h-bold" style="color:#fff; top: 300px;">Nossas instalações</h2>
                        <p></p>
                    </div>
                </div>
                <div class="divider-short"></div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="wow bounceInUp" data-wow-delay="0.2s">

                  <div id="carousel-reviews" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                      <div class="item active">
                        <div class="col-md-4 col-sm-6">
                          <a>
                            <img src = "<?php echo pg; ?>/assets/img/carousel/instalacao/1/1.jpg" class = "img-responsive " alt = "img">
                          </a>
                        </div>
                        <div class="col-md-4 col-sm-6 hidden-xs">
                          <a>
                            <img src = "<?php echo pg; ?>/assets/img/carousel/instalacao/2/2.jpg" class = "img-responsive " alt = "img">
                          </a>
                        </div>
                        <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
                          <a>
                            <img src = "<?php echo pg; ?>/assets/img/carousel/instalacao/3/3.jpg" class = "img-responsive " alt = "img">
                          </a>
                        </div>
                      </div>
                      <div class="item">
                        <div class="col-md-4 col-sm-6">
                          <a>
                            <img src = "<?php echo pg; ?>/assets/img/carousel/instalacao/4/4.jpg" class = "img-responsive " alt = "img">
                          </a>
                        </div>
                        <div class="col-md-4 col-sm-6 hidden-xs">
                          <a>
                            <img src = "<?php echo pg; ?>/assets/img/carousel/instalacao/5/5.jpg" class = "img-responsive " alt = "img">
                          </a>
                        </div>
                        <div class="col-md-4 col-sm-6 hidden-sm hidden-xs">
                          <a>
                            <img src = "<?php echo pg; ?>/assets/img/carousel/instalacao/6/6.jpg" class = "img-responsive " alt = "img">
                          </a>
                        </div>
                      </div>
                    </div>

                  </div>


                  <!--  <div id="owl-works" class="owl-carousel">

                        <?php
                        $result_carousels = "SELECT * FROM sts_carousels_instalacao WHERE sts_situacoe_id=1";
                        $resultado_carousels = mysqli_query($conn, $result_carousels);

                        if (($resultado_carousels) AND ( $resultado_carousels->num_rows != 0)) {?>
                            <?php
                              $resultado_carousels = mysqli_query($conn, $result_carousels);
                              while ($row_carousel = mysqli_fetch_assoc($resultado_carousels)) { ?>
                                <div class = "item">
                                  <a href ="<?php echo pg; ?>/assets/img/carousel/instalacao/<?php echo $row_carousel['id'] ?>/<?php echo $row_carousel['img'] ?>" title = "This is an image title" data-lightbox-gallery = "gallery1" data-lightbox-hidpi = "img/works/2@2x.jpg">
                                    <img src = "<?php echo pg; ?>/assets/img/carousel/instalacao/<?php echo $row_carousel['id'] ?>/<?php echo $row_carousel['img'] ?>" class = "img-responsive " alt = "img">
                                  </a>
                                </div>
                            <?php
                            }
                            ?>
                        <?php
                          }
                        ?>
                    </div> -->
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /Section: works -->
