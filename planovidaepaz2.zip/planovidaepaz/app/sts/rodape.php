<footer>
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-md-4">
                <div class="wow fadeInDown" data-wow-delay="0.1s">
                    <div class="widget">
                        <h5>Sobre o Plano Vida & Paz</h5>
                        <p>
                            Uma empresa consolidada a mais de 10 anos em serviços fúnebres, em constante crecimento, abrangendo todas as regiões nacionais e internacionais.
                        </p>
                    </div>
                </div>
                <div class="wow fadeInDown" data-wow-delay="0.1s">
                    <div class="widget">
                        <h5>Informação</h5>
                        <ul>
                            <li><a href="#intro">Home</a></li>
                            <li><a href="#installation">Instalações</a></li>
                            <li><a href="#pricing">Planos</a></li>
                            <li><a href="#testimonial">Depoimentos</a></li>
                            <li><a href="#contact-us">Contato</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-4">
                <div class="wow fadeInDown" data-wow-delay="0.1s">
                    <div class="widget">
                        <h5>Plano Vida & Paz</h5><br />
                        <ul>
                            <li>
                                <span class="fa-stack fa-lg">
                                    <i class="fa fa-circle fa-stack-2x"></i>
                                    <i class="fa fa-calendar-o fa-stack-1x fa-inverse"></i>
                                </span> Segunda a Segunda, 24 horas.
                            </li>
                            <li>
                                <span class="fa-stack fa-lg">
                                    <i class="fa fa-circle fa-stack-2x"></i>
                                    <i class="fa fa-phone fa-stack-1x fa-inverse"></i>
                                </span> (85) 3498 3162
                            </li>
                            <li>
                                <span class="fa-stack fa-lg">
                                    <i class="fa fa-circle fa-stack-2x"></i>
                                    <i class="fa fa-envelope-o fa-stack-1x fa-inverse"></i>
                                </span> vidaepaz2009@hotmail.com
                            </li>

                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-4">
                <div class="wow fadeInDown" data-wow-delay="0.1s">
                    <div class="widget">
                        <h5>Nossa localização</h5>
                        <p>
                            <strong>Matriz:</strong> Av. Osório de Paiva, 5550 - Siqueira - Fortaleza-CE<br />
                            <strong>Filial:</strong> Av. IX, 693 - Jereissati II - Maracanaú-CE
                        </p>
                    </div>
                </div>
                <div class="wow fadeInDown" data-wow-delay="0.1s">
                    <div class="widget">
                        <h5>Siga-nos</h5>
                        <ul class="company-social">
                            <li class="social-facebook"><a href="https://pt-br.facebook.com/Plano-Vida-e-Paz-703319616410706/"><i class="fa fa-facebook"></i></a></li>
                            <li class="social-instagram"><a href="https://www.instagram.com/planovidaepaz/?hl=pt-br"><i class="fa fa-instagram"></i></a></li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="sub-footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 col-md-6 col-lg-6">
                    <div class="wow fadeInLeft" data-wow-delay="0.1s">
                        <div>
                         <p>&copy;Copyright -   <a href="http://www.bis.eti.br" > <img src="assets/img/logo/ico.png" width:"25px"; height:"35px;"></a>. Todos os direitos reservados.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
