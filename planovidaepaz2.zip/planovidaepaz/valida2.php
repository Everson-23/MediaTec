<!doctype html>
<?php
 include_once 'conexaovelo.php';
 $user = filter_input(INPUT_POST,'user',FILTER_SANITIZE_STRING);  
 $senha = filter_input(INPUT_POST  ,'senha', FILTER_SANITIZE_STRING);


 if((!empty($senha)) AND (!empty($user))){ 
     $consu = "SELECT senha, usuario FROM adm WHERE usuario = '$user' AND senha='$senha'"; 
     $senna = mysqli_query($conec,$consu) or die (mysql_error());
     $result = mysqli_fetch_assoc($senna);

   

     if ($result['senha'] == $senha AND $result['usuario'] == $user) {
        
         header("Location: adm.php");
     }else{
       echo" 
         Senha e/ou usuário Incorreto(s)!
           "; }
 }else{
   echo"
             Você não pode  deixar nenhum campo vazio!
                " ;  } 
            



?>