<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Velório Online</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.5.10/css/mdb.min.css" rel="stylesheet">
</head>

</head>
<body>
  <!-- Menu -->
<nav class="navbar navbar-dark light-color">
<a class="navbar-brand" href="index.php">
    <img src="logov.png" height="60" class="d-inline-block align-top" alt=""> 
</a>
 
<strong> <a href="index.php"> Home </a></strong>
<h3 class="h3-responsive" style="color:blue;">Velório Online</h3>
</nav>

<div style="padding-top:50px;">
  <!-- Fim do Menu -->
   <center> <blockquote class="blockquote">
  <p class="mb-0">Não sabe como usar o recurso velório virtual?</p>
       <a class="btn btn-primary" data-toggle="collapse" href="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
   Clique aqui
  </a>
</blockquote>
       <div class="collapse" id="collapseExample">
  <div class="mt-3">
   Este tutorial é para uso no Internet Explorer <img src="ie.png" width="50px" height="50px"> se preferir utilizar outro navegador siga para turorial sem o Google chrome. <a href="">Tutorial sem o Chrome</a>
      
<br>
      <br>
    <p class="h2">PASSO 1:</p>
       <p class="mb-0">Utilizando o navegador Internet Explorer acessa o site do Plano Vida & Paz e dirija-se a área de obtuário online.</p><a href="">Pode acessar por esse link</a>
        <br> 
      <img src="1o.png" width="720" height="480">
    <br>
      <br>
       <p class="h2">PASSO 2:</p>
       <p class="mb-0">No obtuário online selecione o ente querido que gostaria de acompanhar o velório.</p>
        <br> 
      <img src="2o.png" width="720" height="480">
       <br>
      <br>
       <p class="h2">PASSO 3:</p>
       <p class="mb-0">Na tela "Senha" selecione a sala fornecida pelo Plano Vida & Paz e digite a senha provida pelo mesmo e clique em "Entrar".</p>
        <br> 
      <img src="3o.png" width="720" height="480">
       <br>
      <br>
       <p class="h2">PASSO 4:</p>
       <p class="mb-0">Clique no link de acesso "Acessar Sala 1"</p>
        <br> 
      <img src=".png" width="720" height="480">
          <br>
      <br>
       <p class="h2">PASSO 5:</p>
       <p class="mb-0">Após o redirecionamento, preencha os campos usuário e senha fornceidos pelo Plano Vida & Paz como descrito abaixo.</p>
        <br> 
      <img src=".png" width="720" height="480">
           <br>
      <br>
       <p class="h2">PASSO 6:</p>
       <p class="mb-0">Selecione a câmera correspondente ao número de sua sala. Exemplo: Para a sala 1 selecione a cãmera 1 e com dois cliques assista em tela cheia.</p>
        <br> 
      <img src=".png" width="720" height="480">
  </div>
</div>
</center>
    
    
    
    
    
    
    
    
    
     <!-- JQuery -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.13.0/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.5.10/js/mdb.min.js"></script>
</body>
</html>