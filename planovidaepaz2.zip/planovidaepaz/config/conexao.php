<?php 
if(!isset($seguranca)){
    exit;
}
$servidor = "planovidaepaz.mysql.uhserver.com";
$usuario = "planovida";
$senha = "b@nc0b1s";
$dbname = "planovidaepaz";

//Criar a conexao
$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);

if(!$conn){
    die("Falha na conexao: " . mysqli_connect_error());
}else{
    //echo "Conexao realizada com sucesso";
}
