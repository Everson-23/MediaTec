$(document).ready(function (){
    $("#sendmail").click(function (){
       var form = new FormData($("#main-contact-form")[0]);
       $.ajax({
           url: 'mail.php',
           type: 'post',
           dataType: 'json',
           cache: false,
           processData: false,
           contentType: false,
           data: form,
           timeout: 8000,
           success: function(resultado){
               $("#resultado").php(resultado);
           }
       });
    });
});

