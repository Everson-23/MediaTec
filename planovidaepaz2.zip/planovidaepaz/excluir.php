<?php

include_once 'conexao1.php';
$nome = filter_input(INPUT_POST ,'nome', FILTER_SANITIZE_STRING);
$adm =  filter_input(INPUT_POST ,'adm', FILTER_SANITIZE_STRING);
$enviar = filter_input(INPUT_POST ,'enviar', FILTER_SANITIZE_STRING);
$adc = filter_input(INPUT_POST ,'adc', FILTER_SANITIZE_STRING);

 if($enviar == 1){
  $delete = "DELETE FROM velorio WHERE nome = '$nome'";

	 if($canec -> query($delete) === TRUE){
		 echo "Apagado com sucesso";
 	}else{
	 	 echo "O sistema não conseguiu excluir";
 			}
	 if(empty($nome)){
		 echo "digite alguma coisa!";
}
 
  }else{
	
  }

 if($adc == 2) {
$del = "DELETE FROM adm WHERE usuario = '$adm'";

	 if($canec -> query($del) === TRUE){
	 	echo "Apagado com sucesso";
 	}else{
	 	echo "O sistema não conseguiu excluir";
	 	}
	 if(empty($adm)){
		echo "digite alguma coisa!";

} 
 }else{
	 
  }

?>