<?php  




?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Administrador</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.5.10/css/mdb.min.css" rel="stylesheet">
</head>
<body> 
<!-- Menu -->
<nav class="navbar navbar-dark light-color">
<a class="navbar-brand" href="index.php">
    <img src="logov.png" height="60" class="d-inline-block align-top" alt=""> 
</a>
 
	<strong> <a href="index.php"> Home </a></strong>
    <div class="btn-group">

  <!-- Obituário -->
   <a class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
    aria-expanded="false">Obituario</a>

  <div class="dropdown-menu">
    <a href="#obituario">Cadastrar</a>
    <a  href="#excluirobi">Excluir</a>
  </div>
	</div>
	<!-- 
	 <div class="btn-group">
 <a class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
    aria-expanded="false">Evento</a>
	 <div class="dropdown-menu">
    <a href="#evento">Cadastrar</a>
    <a  href="#">Excluir</a>
  </div>
  </div>
-->
	<!-- Senha e adm -->
	 <div class="btn-group">
<a class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
    aria-expanded="false">Cadastrar administrador</a>
		  <div class="dropdown-menu">
    <a class="dropdown-item" href="#novo">Cadastrar Administrador</a>
    <a class="dropdown-item"  href="#excluiradm">Excluir</a>
  </div>
  </div>
<h3 class="h3-responsive" style="color:blue;">Área do Administrador</h3>
</nav>

<div style="padding-top:50px;">
    
    <center>
<!-- Default form register -->
	<div style=" width: 50%;" id="obituario">
<form class="text-center border border-light p-5" method="post" action="enviar.php">

    <p class="h4 mb-4">Cadastrar no Obituário</p>

    <div class="form-row mb-2">
        <div class="col">
            <!-- First name -->
            <input type="text" id="defaultRegisterFormFirstName" class="form-control" placeholder="Nome" name="nome">
        </div>
        <div class="col">
            <!-- Last name -->
            <input type="text" id="defaultRegisterFormLastName" class="form-control" placeholder="sobrenome" name="sobrenome">
        </div>
    </div>

    <!-- E-mail -->
    <input type="text" id="defaultRegisterFormEmail" class="form-control mb-4" placeholder=" Data de Nascimento: 'dd/mm/aaaa'" name="data_nasci">

    <!-- Password -->
    <input type="text" id="defaultRegisterFormPassword" class="form-control" placeholder="Data de Falecimento: 'dd/mm/aaaa'" name="data_fl" >
    <small id="defaultRegisterFormPasswordHelpBlock" class="form-text text-muted mb-4">
      
    </small>

	<strong><p>Escolha onde ocorrerá o  velório:</p></strong>
    
<input type="text" id="defaultRegisterPhonePassword" class="form-control" placeholder="Local do velório" aria-describedby="defaultRegisterFormPhoneHelpBlock" name="localvel">
    <small id="defaultRegisterFormPhoneHelpBlock" class="form-text text-muted mb-4">
    </small>
	
	
	<!-- Local do Sepultamento -->
	<input type="text" id="defaultRegisterPhonePassword" class="form-control" placeholder="Local Sepultamento" aria-describedby="defaultRegisterFormPhoneHelpBlock" name="localente">
    <small id="defaultRegisterFormPhoneHelpBlock" class="form-text text-muted mb-4">
    </small>
	
   <!-- Horário e Data Velório -->
	   <input type="text" id="defaultRegisterPhonePassword" class="form-control" placeholder="Horário e data Velório" aria-describedby="defaultRegisterFormPhoneHelpBlock" name="horariovelorio">
    <small id="defaultRegisterFormPhoneHelpBlock" class="form-text text-muted mb-4">
		Digite da seguinte forma: "Data: dia/mês/ano" "Horário: 12-00 (Formato 24 Horas)" 
    </small>
	
	 <!-- Horário e Data Enterro -->
	   <input type="text" id="defaultRegisterPhonePassword" class="form-control" placeholder="Horário e data Sepultamento" aria-describedby="defaultRegisterFormPhoneHelpBlock" name="horarioent">
    <small id="defaultRegisterFormPhoneHelpBlock" class="form-text text-muted mb-4">
		Digite da seguinte forma: "Data: dia/mês/ano" "Horário: 12-00 (Formato 24 Horas)" 
    </small>
	<strong><p>Escolha em que sala irá ocorrer o velório:</p></strong>
       <input type="text" id="defaultRegisterPhonePassword" class="form-control" placeholder="Sala onde ocorrerá o velório" aria-describedby="defaultRegisterFormPhoneHelpBlock" name="sala">
	<!-- Group of default radios - option 1 -->
<!-- Default inline 1-->


    <!-- Sign up button -->
    <button class="btn btn-info my-4 btn-block" type="submit" name="enviar" value="1"> 
		Cadastrar</button>

    

 

</form>
	</center>
		
		</div>
	
	<center>
				<div id="excluirobi" style="width: 50%; padding-top:50px;">
		<form class="text-center border border-light p-5" method="POST" action="excluir.php">
			<p class="h4 mb-4">Excluir do obituário</p>
			 <input type="text" id="defaultRegisterFormEmail" class="form-control mb-4" placeholder="Digite o nome do falecido" name="nome">
			 <button class="btn btn-info my-4 btn-block" type="submit" name="enviar" value="1">Excluir</button>
			  </form>
	</div>
		</center>
	
	
	<!-- 
	
<center>
	<div style="padding-top:100px;">
    
	<div id="evento" style="width: 50%;">
	<form class="text-center border border-light p-5"  enctype="multipart/form-data" method="POST" action="enviar.php">
			 <p class="h4 mb-4">Cadastrar Evento</p>
<label for="exampleForm2"><strong>Título do evento</strong></label>
<input type="text" id="exampleForm2" class="form-control" name="titulo" placeholder="Digite o Título">  	
 
<label for="exampleForm2"> <strong>Data do evento</strong></label>
<input type="text" id="exampleForm2" class="form-control" name="data" placeholder="Digite a data por extenso : '17 de Dezembro'"> 	
		<div class="form-group">
    <label for="exampleFormControlTextarea3"><strong>Digite o Conteúdo</strong></label>
    <textarea class="form-control" id="exampleFormControlTextarea3" rows="7" name="conteudo"></textarea>
</div>
		 <div class="file-field">
			 <strong><p> Procure a Foto</p></strong>
        <div class="btn btn-primary btn-sm float-left">
            <span>Procure a foto</span>
            <input type="file" name="foto">
        </div>
       <div class="file-path-wrapper">
            <input class="file-path validate" type="text" placeholder="digite o nome da foto, seguido da extensão" name="nome_foto">
        </div>
    </div>
		 <button class="btn btn-info my-4 btn-block" type="submit" name="botao" value="2"> Cadastrar</button>
</form>
</div>
		</div>
	</center>
	
	<center>
				<div id="excluireven" style="width: 50%; padding-top:50px;">
		<form class="text-center border border-light p-5" method="POST" action="excluir.php">
			<p class="h4 mb-4">Excluir Evento</p>
			 <input type="text" id="defaultRegisterFormEmail" class="form-control mb-4" placeholder="Digite o título do evento" name="evento">
			 <button class="btn btn-info my-4 btn-block" type="submit" name="enviar">Excluir</button>
			  </form>
	</div>
		</center>
-->

<center>
	<div style="padding-top:50px;">
    
	<div id="novo" style="width: 50%;">
	<form class="text-center border border-light p-5"  enctype="multipart/form-data" method="POST" action="enviar.php">
			 <p class="h4 mb-4">Cadastrar novo administrador</p>
<label for="exampleForm2"><strong>Usuário</strong></label>
<input type="text" id="exampleForm2" class="form-control" name="usuario" placeholder="Digite o Usuário">  	
 
<label for="exampleForm2"> <strong>Senha</strong></label>
<input type="text" id="exampleForm2" class="form-control" name="senhaadm" placeholder="Digite a senha"> 	

		 <button class="btn btn-info my-4 btn-block" type="submit" name="adm" value="3">Cadastrar</button>
</form>
</div>
		</div>
	</center>
	<center>
				<div id="excluiradm" style="width: 50%; padding-top:50px;">
		<form class="text-center border border-light p-5" method="POST" action="excluir.php">
			<p class="h4 mb-4">Excluir admistrador</p>
			 <input type="text" id="defaultRegisterFormEmail" class="form-control mb-4" placeholder="Digite o usuário do administrador que deseja excluir" name="adm">
			 <button class="btn btn-info my-4 btn-block" type="submit" name="adc" value="2">Excluir</button>
			  </form>
	</div>
		</center>
	







 <!-- JQuery -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.13.0/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.5.10/js/mdb.min.js"></script>








</body> 
</html>