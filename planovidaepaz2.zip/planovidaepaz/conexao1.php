<?php  

$servero = "planovidaepaz.mysql.uhserver.com";
$usero = "planovida";
$passw = "b@nc0b1s";
$dbnomeo = "planovidaepaz";

//Criar a conexao
$canec = mysqli_connect($servero, $usero, $passw, $dbnomeo);

if(!$canec){
    die("Falha na conexao: " . mysqli_connect_error("Contate o suporte evesonaqw@gmail.com "));
}else{
   //echo "Conexao realizada com sucesso";
}
?>