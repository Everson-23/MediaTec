<?php include_once 'conexaovelo.php';
 
 $falecido = "SELECT nome, sobrenome, data_nascimento, data_falecimento, local_velorio, local_enterro, horario_velorio, horario_enterro, sala FROM velorio";
 $falecidos = mysqli_query($conec,$falecido) or die (mysql_error());
 $result = mysqli_fetch_assoc($falecidos);
 $contagem = mysqli_num_rows($falecidos);
 header('Content-Type: text/html; charset=utf-8');


?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Obituário Online</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.5.10/css/mdb.min.css" rel="stylesheet">
</head>
<body> 

<!-- Menu -->
<nav class="navbar navbar-dark light-color">
<a class="navbar-brand" href="index.php">
    <img src="logov.png" height="60" class="d-inline-block align-top" alt=""> 
</a>
 
<strong> <a href="index.php"> Home </a></strong> 
	<strong><a href="" data-toggle="modal" data-target="#modalRegisterForm">Administrador</a></strong>
</div>

<h3 class="h3-responsive" style="color:blue;">Obituário Online</h3>
</nav>

<div style="padding-top:50px;">
    
 <!--Panel-->
 <?php
   
  
        // inicia o loop que vai mostrar todos os dados
     
            if($result > 0){
        do {
?>      
                   <!-- Obituário Online --> 
                   
             <span class="block-example border border-primary"> 
             <div style="padding-left:20%;">
         <div class="card w-75" >
        <table class="table.table-borderless"> 
         <div class="card-body"> 
        <thead>
        <tr>
        <th><h2 class="h2-responsive"><?php echo utf8_encode($result['nome'].'      '.$result['sobrenome']);?></h2></th>
            <th><p> Velório </p></th> 
            <th> <p> Sepultamento </p></th> 
            </tr> 
            </thead>
        <tr>
         <td> <i class="fa fa-star" aria-hidden="true"></i> <p><small> <?php echo utf8_encode($result['data_nascimento']); ?></small></p></td> <td> <i class="fa fa-building" aria-hidden="true"></i> <p><small> <?php echo utf8_encode  ($result['local_velorio']);  
            $localvel = $result ['local_velorio']; ?></small></p></td><td><i class="fa fa-clock-o" aria-hidden="true"></i> <p><small> <?php echo utf8_encode($result['horario_enterro']); ?></small></p> </td>
        </tr>
        <tr>
         <td><i class="fa fa-plus" aria-hidden="true"></i> <p><small> <?php echo utf8_encode($result['data_falecimento']); ?></small></p> </td>  <td><i class="fa fa-clock-o" aria-hidden="true"></i> <p><small> <?php echo utf8_encode ($result['horario_velorio']); ?></small></p></td><td><i class="fa fa-map-marker" aria-hidden="true"></i><p><small> <?php echo utf8_encode($result ['local_enterro']); ?></small></p> </td><td><i class="fa fa-cube" aria-hidden="true"></i><p><small> <?php echo utf8_encode($result ['sala']); 
            $sala = $result ['sala']; ?></small></p> </td>
        </tr>
        </table> 
             <div>
                 
         <?php    
            if($sala == "sala 1" OR $sala == "Sala 1" AND $localvel == "Filial Maracanaú" OR $localvel == "Filial Maracanau" OR $localvel == "filial Maracanaú" OR $localvel == "filial Maracanau" OR $localvel == "filial maracanau" OR $localvel == "Filial maracanaú" OR $localvel == "Filial maracanau" OR $localvel == "filial Maracanaú" OR $localvel == "filial Maracanau" ){ ?>
         <a href="index.php" class="btn btn-primary" data-toggle="modal" data-target="#modalLoginForm">Velório Virtual</a>
        <?php  }else{
               // echo 'velório não disponível';
            } if($sala == "sala 2" OR $sala == "Sala 2"  AND $localvel == "Filial Maracanaú" OR $localvel == "Filial Maracanau" OR $localvel == "filial Maracanaú" OR $localvel == "filial Maracanau" OR $localvel == "filial maracanau" OR $localvel == "Filial maracanaú" OR $localvel == "Filial maracanau" OR $localvel == "filial Maracanaú" OR $localvel == "filial Maracanau" ){ ?>
            <a href="index.php" class="btn btn-primary" data-toggle="modal" data-target="#modalLoginForm2">Velório Virtual</a>
     <?php   }else{
               // echo 'velório não disponível'; 
            } if($localvel == "casa do falecido" OR $localvel == "Casa do Falecido" OR $localvel == "Casa do falecido" OR $localvel == "casa do Falecido" OR $localvel == "Sede Osório de Paiva" OR $localvel == "sede osorio de paiva" OR $localvel == "Sede Osorio de Paiva"  ){
                echo 'Velório não disponível';
            }
                 ?>
             </div>
          </div> 
          
          </div> 
       </div> </span> 
<?php
        // finaliza o loop que vai mostrar os dados
        }while($result = mysqli_fetch_assoc($falecidos));
    // fim do if 
    }
     ?>  
     <!-- Modal de senhas -->
    
					
					
     <div class="modal fade" id="modalLoginForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header text-center">
                <h4 class="modal-title w-100 font-weight-bold">Senha</h4>
                <button type="btn-primary" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body mx-3">

                <div class="md-form mb-4">
                 <form method="POST" action="valida.php">
					 <h6>Sala 1</h6>
                  
                    <input type="password" class="form-control validate" name="senha">
						
							  </div>
                    </div>
						 <button type="submit" class="btn btn-primary" name="enviar">Entrar</button>
						  </form>
					 </div>
			  </div>
    </div>
</div> 
    </div>
      
					 
			
					   <div class="modal fade" id="modalLoginForm2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header text-center">
                <h4 class="modal-title w-100 font-weight-bold">Senha</h4>
                <button type="btn-primary" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body mx-3">

                <div class="md-form mb-4">
                 <form method="POST" action="valida.php">
					 <!-- SALA 2 -->
					 <p>Sala 2</p>
					
                    <input type="password" class="form-control validate" name="senha2">
									           </div>
            </div>
            <div class="modal-footer d-flex justify-content-center">
            
            <button type="submit" class="btn btn-primary" name="enviar">Entrar</button>
            </form>
            </div> 

        
        </div>
    </div>
</div> 
						
     
                  
	<!-- 	Modal administrador -->
	
<div class="modal fade" id="modalRegisterForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header text-center">
                <h4 class="modal-title w-100 font-weight-bold">Sign up</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body mx-3">
                <div class="md-form mb-5">
					<form method="POST" action="valida2.php">
                    <i class="fa fa-user prefix grey-text"></i>
                    <input type="text" id="orangeForm-name" class="form-control validate" name="user">
                    <label data-error="wrong" data-success="right" for="orangeForm-name">Usuário</label>
				</div>
				
                <div class="md-form mb-4">
                    <i class="fa fa-lock prefix grey-text"></i>
                    <input type="password" id="orangeForm-pass" class="form-control validate" name="senha">
                    <label data-error="wrong" data-success="right" for="orangeForm-pass">Sua senha</label>
                </div>

            </div>
            <div class="modal-footer d-flex justify-content-center">
                <button class="btn btn-primary">Entrar</button>
            </div>
        </form>
		</div>
    </div>
</div>

<!-- Fim do adm -->

 <!-- JQuery -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.13.0/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.5.10/js/mdb.min.js"></script>


</body>
</html>