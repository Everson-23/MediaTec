   <!-- Validação de senha -->

<?php
 include_once 'conexaovelo.php';
 $enviar = filter_input(INPUT_POST,'enviar',FILTER_SANITIZE_STRING);  
 $senha = filter_input(INPUT_POST  ,'senha', FILTER_SANITIZE_STRING);
 $senha2 = filter_input(INPUT_POST  ,'senha2', FILTER_SANITIZE_STRING);
 $sala1 =  $_SESSION['sala1'];
 $sala2 =   $_SESSION['sala2'];
 


 if((!empty($senha))){ 
     $consu = "SELECT senha FROM senhas WHERE senha = '$senha'"; 
     $senna = mysqli_query($conec,$consu) or die (mysql_error());
     $result = mysqli_fetch_assoc($senna);
 
     if ($result['senha'] == $senha) {
        
         header("Location: velorio.php");
     }else{
       echo" 
         Senha Incorreta!
           "; }
 }else{
	 echo "Digite sua senha!!!";
 }
 
   if((!empty($senha2))){ 
	 $consu2 = "SELECT senha FROM senhas WHERE senha = '$senha2'"; 
     $sennac = mysqli_query($conec,$consu2) or die (mysql_error());
     $f1 = mysqli_fetch_assoc($sennac);
	   
	   
     if ($f1['senha'] == $senha2) {
        
         header("Location: velorio2.php"); 
	 }else{
		 echo "Senha Incorreta!";
	 }
 
 }else{
   echo"
             Digite sua senha!
                " ;  } 
            



?>