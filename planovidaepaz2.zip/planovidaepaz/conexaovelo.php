<?php  

$serv = "planovidaepaz.mysql.uhserver.com";
$user = "planovida";
$pass = "b@nc0b1s";
$dbnome = "planovidaepaz";

//Criar a conexao
$conec = mysqli_connect($serv, $user, $pass, $dbnome);

if(!$conec){
    die("Falha na conexao: " . mysqli_connect_error("Contate o suporte evesonaqw@gmail.com "));
}else{
   // echo "Conexao realizada com sucesso";
}
?>