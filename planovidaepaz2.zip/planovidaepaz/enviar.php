
<?php
 
include_once 'conexao1.php';
include "Upload.class.php";
$recebido =  filter_input(INPUT_POST ,'enviar', FILTER_SANITIZE_STRING); 
$botao =  filter_input(INPUT_POST ,'botao', FILTER_SANITIZE_STRING);
$adm=  filter_input(INPUT_POST ,'adm', FILTER_SANITIZE_STRING);
$nome =  filter_input(INPUT_POST ,'nome', FILTER_SANITIZE_STRING); 
$sobrenome=  filter_input(INPUT_POST ,'sobrenome', FILTER_SANITIZE_STRING);
$datans=   filter_input(INPUT_POST ,'data_nasci', FILTER_SANITIZE_STRING);
$data_fl =   filter_input(INPUT_POST ,'data_fl', FILTER_SANITIZE_STRING);
$localvel=   filter_input(INPUT_POST ,'localvel', FILTER_SANITIZE_STRING);
$localent=   filter_input(INPUT_POST ,'localente', FILTER_SANITIZE_STRING);
$horavel=    filter_input(INPUT_POST ,'horariovelorio', FILTER_SANITIZE_STRING);
$horaent=    filter_input(INPUT_POST ,'horarioent', FILTER_SANITIZE_STRING);
$sala=    filter_input(INPUT_POST ,'sala', FILTER_SANITIZE_STRING);
$titulo = filter_input(INPUT_POST,'titulo',FILTER_SANITIZE_STRING);  
$data = filter_input(INPUT_POST  ,'data', FILTER_SANITIZE_STRING);
$conteudo = filter_input(INPUT_POST  ,'conteudo', FILTER_SANITIZE_STRING); 
$foto = filter_input(INPUT_POST  ,'nome_foto', FILTER_SANITIZE_STRING); 
$usuario = filter_input(INPUT_POST , 'usuario', FILTER_SANITIZE_STRING);
$senha = filter_input(INPUT_POST, 'senhaadm', FILTER_SANITIZE_STRING);
$sala = filter_input(INPUT_POST, 'sala', FILTER_SANITIZE_STRING);







				if ((isset($_POST["submit"])) && (! empty($_FILES['foto']))){
					$upload = new Upload($_FILES['foto'], 1000, 800, "/assets/img/noticias/");
                    echo $upload->salvar();
  				}
					 

                     
			
				
					
				
									
    			if ($recebido == 1){
					 
					$falecido = "INSERT INTO velorio (nome,sobrenome, data_nascimento, data_falecimento, local_velorio, local_enterro, horario_velorio, horario_enterro, sala)
 					VALUES ('$nome','$sobrenome', '$datans', '$data_fl', '$localvel', '$localent', '$horavel', '$horaent','$sala')";
					
 					if($canec -> query($falecido) === TRUE){
	 				    echo 'Informações Cadastradas com sucesso!';
 					
					}else{
						echo "Informações não cadastradas, entre em contato com o suporte evesonaqw@gmail.com";
 						}

					if (empty($nome)) {
                        echo "Digite alguma coisa!";
							}
					
				   }else{
				
						} 
               
		
	              
		/*			 if($botao == 2) {
						 
						  
				   $falecido = "INSERT INTO sts_eventos (nome, data, img, conteudo)
   				   VALUES ('$titulo', '$data', $foto, '$conteudo')";

					if($canec -> query($falecido) === TRUE){
						echo "Informações Cadastradas com sucesso";
				    }else{
						echo"Informações não cadastradas, entre em contato com o suporte evesonaqw@gmail.com";
										}
						
				    }else{
			
								}
				*/
					 
						  
				   if($adm == 3 AND $sede2){		  
						 
		          $falecido = "INSERT INTO adm (usuario,senha)
 		          VALUES ('$usuario', '$senha')";
				 
				  if($canec -> query($falecido) === TRUE){
				  echo "Informações Cadastradas com sucesso";
 			      }else{
				  echo "Informações não cadastradas, entre em contato com o suporte evesonaqw@gmail.com";
			           }
				 
					}else{
					
				 
					  }

?>